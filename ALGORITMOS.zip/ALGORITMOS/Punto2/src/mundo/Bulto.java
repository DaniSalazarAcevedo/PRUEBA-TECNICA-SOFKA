package mundo;


public class Bulto {
   
    private final double VALOR_DE_CERO_A_VENTICINCO_KG = 0;
    
    private final double VALOR_DE_VENTISEIS_A_TRECIENTOS_KG = 1500;
    
    private final double VALOR_DE_TRECIENTOS_UNO_A_QUINIENTOS_KG = 2500;
        
    
   
    private String descripcion;
    
    private double peso;
    
    private double valor;
    
    private String propietario;
    
    
    
    public Bulto( String descripcion, double peso, String propietario) {
        this.descripcion = descripcion;
        this.peso = peso;
        this.propietario = propietario;
        this.calcularValor();
    }
    
    
    
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    private void calcularValor(){
        if(this.peso >= 0 && this.peso <= 25){
            this.valor = this.VALOR_DE_CERO_A_VENTICINCO_KG;
        }else if(this.peso > 25 && this.peso <= 300){
            this.valor = this.peso * this.VALOR_DE_VENTISEIS_A_TRECIENTOS_KG;
        }else if(this.peso > 300 && this.peso <= 500){
            this.valor = this.peso * this.VALOR_DE_TRECIENTOS_UNO_A_QUINIENTOS_KG;
        }
        
    }    
}
